import { useState, useCallback } from 'react';
import api from '../services/api';
import { 
  LoginRequest, 
  RegisterCustomerRequest, 
  RegisterTherapistRequest, 
  UpdateProfileRequest, 
  CreateMeetingRequest,
  UpdateMeetingRequest,
  ParticipantStatus,
  AuthResponse,
  User,
  Meeting,
  SuccessResponse,
  UsersListResponse,
  Rating,
  SubmitRatingRequest,
  NotRatedBookingsResponse,
  RatingsListResponse
} from '../types/api.types';

// API istekleri için genel hook (tek parametre)
export function useApi<T, P>(
  apiFunc: (params: P) => Promise<T>
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);

  const request = useCallback(
    async (params: P) => {
      setLoading(true);
      setError(null);
      try {
        const result = await apiFunc(params);
        setData(result);
        return result;
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        setError(error);
        throw error;
      } finally {
        setLoading(false);
      }
    },
    [apiFunc]
  );

  return {
    data,
    loading,
    error,
    request,
  };
}

// Parametre almayan API istekleri için hook
export function useApiNoParams<T>(
  apiFunc: () => Promise<T>
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);

  const request = useCallback(
    async () => {
      setLoading(true);
      setError(null);
      try {
        const result = await apiFunc();
        setData(result);
        return result;
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        setError(error);
        throw error;
      } finally {
        setLoading(false);
      }
    },
    [apiFunc]
  );

  return {
    data,
    loading,
    error,
    request,
  };
}

// İki parametreli API istekleri için hook
export function useApiWithTwoParams<T, P1, P2>(
  apiFunc: (param1: P1, param2: P2) => Promise<T>
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);

  const request = useCallback(
    async (param1: P1, param2: P2) => {
      setLoading(true);
      setError(null);
      try {
        const result = await apiFunc(param1, param2);
        setData(result);
        return result;
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));
        setError(error);
        throw error;
      } finally {
        setLoading(false);
      }
    },
    [apiFunc]
  );

  return {
    data,
    loading,
    error,
    request,
  };
}

// Login için özelleştirilmiş hook
export function useLogin() {
  return useApi<AuthResponse, LoginRequest>(api.users.login);
}

// Müşteri kaydı için özelleştirilmiş hook
export function useRegisterCustomer() {
  return useApi<AuthResponse, RegisterCustomerRequest>(api.users.registerCustomer);
}

// Terapist kaydı için özelleştirilmiş hook
export function useRegisterTherapist() {
  return useApi<AuthResponse, RegisterTherapistRequest>(api.users.registerTherapist);
}

// Profil bilgileri için özelleştirilmiş hook
export function useGetProfile() {
  return useApiNoParams<User>(api.users.getProfile);
}

// Profil güncelleme için özelleştirilmiş hook
export function useUpdateProfile() {
  return useApi<User, UpdateProfileRequest>(api.users.updateProfile);
}

// Toplantı oluşturma için özelleştirilmiş hook
export function useCreateMeeting() {
  return useApi<Meeting, CreateMeetingRequest>(api.meetings.create);
}

// Toplantıları listeleme için özelleştirilmiş hook
export function useListMeetings() {
  return useApi<any, {page?: number, limit?: number}>((params) => {
    return api.meetings.listAll(params?.page, params?.limit);
  });
}

// Toplantı detayı için özelleştirilmiş hook
export function useGetMeeting() {
  return useApi<Meeting, string>(api.meetings.getById);
}

// Toplantı güncelleme için özelleştirilmiş hook
export function useUpdateMeeting() {
  return useApiWithTwoParams<Meeting, string, UpdateMeetingRequest>(api.meetings.updateById);
}

// Toplantı silme için özelleştirilmiş hook
export function useDeleteMeeting() {
  return useApi<SuccessResponse, string>(api.meetings.deleteById);
}

// Toplantı katılımcı durumu güncelleme için özelleştirilmiş hook
export function useUpdateParticipantStatus() {
  return useApiWithTwoParams<Meeting, string, ParticipantStatus>(api.meetings.updateParticipantStatus);
}

// Terapist durumunu güncellemek için özelleştirilmiş hook
export function useUpdateTherapistStatus() {
  return useApiWithTwoParams<User, string, 'active' | 'pending' | 'rejected' | 'suspended'>(api.users.updateTherapistStatus);
}

// Bekleyen terapistleri getirmek için özelleştirilmiş hook
export function useGetPendingTherapists() {
  return useApiNoParams<UsersListResponse>(api.users.getPendingTherapists);
}

// Terapistleri getirmek için özelleştirilmiş hook - doğrudan /therapists endpoint'ini kullanır
export function useGetTherapists() {
  return useApi<UsersListResponse, {page?: number, limit?: number}>((params) => {
    return api.request<UsersListResponse>(`/therapists?page=${params?.page || 1}&limit=${params?.limit || 10}`);
  });
}

// Kullanıcının booking'lerini listeleme için hook
export function useListUserBookings() {
  // Giriş yapmış kullanıcının ID'si state veya context'ten alınmalı,
  // şimdilik hook içinde doğrudan alınamıyor.
  // Bu yüzden request fonksiyonu userId alacak şekilde düzenlendi.
  // Kullanıcı ID'si context API veya benzeri bir yöntemle sağlanmalı.
  return useApi<any[], number>(api.bookings.listForUser); // any[] yerine Booking[] tipi kullanılmalı
}

// Terapistin booking'lerini listeleme için hook (YENİ)
export function useListTherapistBookings() {
  // Bu hook da therapistId parametresi alacak
  return useApi<any[], number>(api.bookings.listForTherapist);
}

// Terapist isim araması için hook
export function useSearchTherapistByName() {
  // useApi hook'unu kullanalım (tek parametre: arama terimi)
  return useApi<{ id: number; name: string }[], string>(
    // API fonksiyonu: api.request'i çağırır
    async (searchTerm: string) => {
      if (!searchTerm || searchTerm.length < 2) {
        // Arama terimi yoksa veya çok kısaysa boş dizi döndür
        return [];
      }
      // API isteğini yap ve dönen veriyi direkt döndür
      // Önemli: api.request'in bu endpoint'i desteklemesi gerekiyor
      try {
           const results = await api.request<{ id: number; name: string }[]>(
             `/therapists/search-name?name=${encodeURIComponent(searchTerm)}`
           );
           return results || []; // API boş yanıt dönerse boş dizi sağla
         } catch (error) {
           // API 404 dönerse (sonuç yoksa) veya başka bir hata olursa boş dizi döndür
           // Gerçek hata mesajını logla
           console.error(`Search request failed for term "${searchTerm}":`, error);
           return []; // Hata durumunda boş dizi döndürerek UI'ın çökmesini engelle
         }
    }
  );
}

// Belirli bir terapist ve tarih için dolu saatleri getirme hook'u
export function useGetBookedSlots() {
  // İki parametre: therapistId (number) ve date (string, YYYY-MM-DD)
  // Dönüş tipini string[] olarak belirt
  return useApiWithTwoParams<string[], number, string>(
    // API Fonksiyonu
    async (therapistId: number, date: string) => {
      if (!therapistId || !date) {
        return []; 
      }
      try {
        const endpoint = `/bookings/therapist/${therapistId}/booked-slots?date=${date}`;
        console.log(`Dolu saatler isteniyor: ${endpoint}`);
        // API yanıtının string[] formatında olduğunu varsayıyoruz
        const bookedSlots = await api.request<string[]>(endpoint);
        console.log(`Dolu saatler (${date}):`, bookedSlots);
        return bookedSlots || [];
      } catch (error: any) {
        if (error.message && (error.message.includes('404') || error.message.toLowerCase().includes('not found'))) {
            console.log(`Dolu saat bulunamadı (${date}):`, error.message);
            return []; 
        }
        
        //Ben bunu başaracağım!!!!!
        console.error(`Dolu saatler alınırken hata (${date}):`, error);
        return [];
      }
    }
  );
}

// YENİ: Terapist ID'sine göre seans ücretini getirme hook'u
export function useGetTherapistSessionFee() {
  // Tek parametre: therapistId (number)
  // Dönüş tipi: { sessionFee: number | null }
  return useApi<{ sessionFee: number | null }, number>(
    api.users.getSessionFeeById // src/services/api.ts içinde eklediğimiz fonksiyon
  );
}

// YENİ: Puanlanmamış booking'leri getirme hook'u (güncellendi)
export function useGetNotRatedBookings() {
  // Tek parametre: userId (number)
  // Dönüş tipi: NotRatedBookingsResponse (NotRatedBooking[])
  return useApi<NotRatedBookingsResponse, number>(
    api.ratings.getNotRatedBookings // API fonksiyonu güncellendi
  );
}

// YENİ: Puanlama/Yorum gönderme hook'u (parametre/dönüş tipi güncellendi)
export function useSubmitRating() {
  // Tek parametre: ratingData (SubmitRatingRequest)
  // Dönüş tipi: Rating
  return useApi<Rating, SubmitRatingRequest>(
    api.ratings.submitRating
  );
}

// YENİ: Tüm terapistlerin rating istatistiklerini getirme hook'u
export function useGetRatings() {
  // Parametre almaz
  // Dönüş tipi: RatingsListResponse (TherapistRatingStat[])
  return useApiNoParams<RatingsListResponse>(
    api.ratings.getAllRatings // Bu fonksiyonu src/services/api.ts içinde tanımlamamız gerekecek
  );
}

export default useApi; 