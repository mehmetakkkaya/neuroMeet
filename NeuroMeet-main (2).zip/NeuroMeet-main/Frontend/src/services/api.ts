import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  AuthResponse,
  LoginRequest,
  RegisterCustomerRequest,
  RegisterTherapistRequest,
  RegisterAdminRequest,
  UpdateProfileRequest,
  User,
  UsersListResponse,
  CreateMeetingRequest,
  UpdateMeetingRequest,
  Meeting,
  MeetingsListResponse,
  SuccessResponse,
  ParticipantStatus,
  UploadDocumentRequest,
  Document,
  DocumentResponse,
  DocumentsListResponse,
  SubmitRatingRequest,
  Rating,
  NotRatedBookingsResponse,
  RatingsListResponse
} from '../types/api.types';

// API'nin çalıştığı temel URL
// .env dosyasından alınıyor
let API_URL = '';

// process.env'den değer geliyorsa kullan
if (process.env.API_URL) {
  API_URL = `${process.env.API_URL}/api`;
} 
// Gelmiyorsa platform bazlı varsayılan değeri ayarla
else { 
  API_URL = 'http://192.168.1.50:5000/api'; // iOS Simulator için localhost çalışır
}

console.log('Kullanılan API URL:', API_URL);

// Token için depolama anahtarı
const AUTH_TOKEN_KEY = '@NeuroMeet:authToken';

// Token'ı bellekte de tutalım (hızlı erişim için)
let inMemoryToken: string | null = null;

// Token'ı AsyncStorage'dan yükleyip belleğe alma fonksiyonu
const loadTokenFromStorage = async () => {
  try {
    const storedToken = await AsyncStorage.getItem(AUTH_TOKEN_KEY);
    if (storedToken) {
      inMemoryToken = storedToken;
      console.log("Token AsyncStorage'dan belleğe yüklendi.");
    } else {
      console.log("AsyncStorage'da token bulunamadı.");
    }
  } catch (error) {
    console.error("Token AsyncStorage'dan yüklenirken hata:", error);
  }
};

// Uygulama/modül yüklendiğinde token'ı yüklemeyi dene
// NOT: Bu asenkron işlem bitmeden API isteği yapılırsa token eksik olabilir.
// Ana layout'ta veya context'te bu yüklemenin bitmesini beklemek daha güvenli olabilir.
loadTokenFromStorage(); 

// API istekleri için yardımcı fonksiyonlar
const api = {
  // Token yönetimi
  setToken: async (token: string | null) => {
    inMemoryToken = token; // Bellekteki token'ı güncelle
    if (token) {
      try {
        await AsyncStorage.setItem(AUTH_TOKEN_KEY, token);
        console.log("Token AsyncStorage'a kaydedildi.");
      } catch (error) {
        console.error("Token AsyncStorage'a kaydedilirken hata:", error);
      }
    } else {
      // Token null ise depolamadan da sil
      await api.clearToken(); 
    }
  },
  
  clearToken: async () => {
    inMemoryToken = null; // Bellekteki token'ı temizle
    try {
      await AsyncStorage.removeItem(AUTH_TOKEN_KEY);
      console.log("Token AsyncStorage'dan silindi.");
    } catch (error) {
      console.error("Token AsyncStorage'dan silinirken hata:", error);
    }
  },
  
  getToken: () => {
    // Bellekteki token'ı döndür (başlangıçta yüklendiği varsayılır)
    return inMemoryToken;
  },
  
  // API istekleri için temel fonksiyon
  request: async <T>(
    endpoint: string, 
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET', 
    data?: any
  ): Promise<T> => {
    const url = `${API_URL}${endpoint}`;
    
    console.log(`API isteği yapılıyor: ${method} ${url}`);
    
    // İstek yapılandırması
    const config: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
    };
    
    // Bellekteki güncel token'ı kullan
    const currentToken = api.getToken(); 
    if (currentToken) {
      config.headers = {
        ...config.headers,
        'Authorization': `Bearer ${currentToken}`,
      };
    }
    
    // Body data varsa ekle
    if (data) {
      config.body = JSON.stringify(data);
      console.log('Gönderilen veri:', data);
    }
    
    try {
      const response = await fetch(url, config);
      
      // JSON yanıtını al
      let responseData;
      try {
        responseData = await response.json();
      } catch (jsonError) {
        console.error('JSON parse hatası:', jsonError);
        throw new Error('Sunucu yanıtı işlenemedi. Geçersiz JSON formatı.');
      }
      
      // Başarısız yanıtları kontrol et
      if (!response.ok) {
        console.error('API hata yanıtı:', responseData);
        throw new Error(responseData.message || `HTTP Hata: ${response.status} ${response.statusText}`);
      }
      
      console.log('API yanıtı başarılı:', endpoint);
      return responseData as T;
    } catch (error) {
      // Network hatasının türünü belirle
      if (error instanceof TypeError && error.message === 'Network request failed') {
        console.error('Ağ bağlantısı hatası:', error);
        throw new Error('Sunucuya bağlanılamadı. Lütfen internet bağlantınızı ve sunucu adresini kontrol edin.');
      } else {
        console.error('API isteği başarısız:', error);
        throw error;
      }
    }
  },
  
  // Multipart-form request (dosya upload için)
  uploadFile: async <T>(
    endpoint: string,
    formData: FormData
  ): Promise<T> => {
    const url = `${API_URL}${endpoint}`;
    
    console.log(`Dosya yükleme isteği yapılıyor: ${url}`);
    
    // İstek yapılandırması
    const config: RequestInit = {
      method: 'POST',
      headers: {
        // multipart/form-data için Content-Type belirtilmemeli
        // Fetch API otomatik boundary ekleyecek
      },
      body: formData,
    };
    
    // Bellekteki güncel token'ı kullan
    const currentTokenForUpload = api.getToken();
    if (currentTokenForUpload) {
      config.headers = {
        ...config.headers,
        'Authorization': `Bearer ${currentTokenForUpload}`,
      };
    }
    
    try {
      const response = await fetch(url, config);
      
      // JSON yanıtını al
      let responseData;
      try {
        responseData = await response.json();
      } catch (jsonError) {
        console.error('JSON parse hatası:', jsonError);
        throw new Error('Sunucu yanıtı işlenemedi. Geçersiz JSON formatı.');
      }
      
      // Başarısız yanıtları kontrol et
      if (!response.ok) {
        console.error('API hata yanıtı:', responseData);
        throw new Error(responseData.message || `HTTP Hata: ${response.status} ${response.statusText}`);
      }
      
      console.log('Dosya yükleme başarılı:', endpoint);
      return responseData as T;
    } catch (error) {
      // Network hatasının türünü belirle
      if (error instanceof TypeError && error.message === 'Network request failed') {
        console.error('Ağ bağlantısı hatası:', error);
        throw new Error('Sunucuya bağlanılamadı. Lütfen internet bağlantınızı ve sunucu adresini kontrol edin.');
      } else {
        console.error('Dosya yükleme başarısız:', error);
        throw error;
      }
    }
  },
  
  // Kullanıcı API endpointleri
  users: {
    // Giriş
    login: async (credentials: LoginRequest): Promise<AuthResponse> => {
      const response = await api.request<AuthResponse>('/users/login', 'POST', credentials);
      api.setToken(response.token);
      return response;
    },
    
    // Müşteri kaydı
    registerCustomer: async (userData: RegisterCustomerRequest): Promise<AuthResponse> => {
      const response = await api.request<AuthResponse>('/users/register-customer', 'POST', userData);
      api.setToken(response.token);
      return response;
    },
    
    // Terapist kaydı
    registerTherapist: async (therapistData: RegisterTherapistRequest): Promise<AuthResponse> => {
      const response = await api.request<AuthResponse>('/users/register-therapist', 'POST', therapistData);
      api.setToken(response.token);
      return response;
    },
    
    // Admin kaydı
    registerAdmin: async (adminData: RegisterAdminRequest): Promise<AuthResponse> => {
      return await api.request<AuthResponse>('/users/register-admin', 'POST', adminData);
    },
    
    // Profil bilgilerini getir
    getProfile: async (): Promise<User> => {
      return await api.request<User>('/users/profile');
    },
    
    // Profil bilgilerini güncelle
    updateProfile: async (profileData: UpdateProfileRequest): Promise<User> => {
      return await api.request<User>('/users/profile', 'PUT', profileData);
    },
    
    // Tüm kullanıcıları listele
    listAll: async (page = 1, limit = 10): Promise<UsersListResponse> => {
      return await api.request<UsersListResponse>(`/users?page=${page}&limit=${limit}`);
    },
    
    // Kullanıcı detayı getir
    getById: async (userId: string): Promise<User> => {
      return await api.request<User>(`/users/${userId}`);
    },
    
    // Kullanıcı bilgilerini güncelle
    updateById: async (userId: string, userData: Partial<User>): Promise<User> => {
      return await api.request<User>(`/users/${userId}`, 'PUT', userData);
    },
    
    // Kullanıcı sil
    deleteById: async (userId: string): Promise<SuccessResponse> => {
      return await api.request<SuccessResponse>(`/users/${userId}`, 'DELETE');
    },
    
    // Döküman yükleme
    uploadDocument: async (documentData: FormData): Promise<DocumentResponse> => {
      return await api.uploadFile<DocumentResponse>('/users/documents', documentData);
    },
    
    // Döküman listele
    getDocuments: async (): Promise<DocumentsListResponse> => {
      return await api.request<DocumentsListResponse>('/users/documents');
    },
    
    // Döküman sil
    deleteDocument: async (documentId: string): Promise<SuccessResponse> => {
      return await api.request<SuccessResponse>(`/users/documents/${documentId}`, 'DELETE');
    },
    
    // Terapist durumunu güncelleme (onaylama/reddetme)
    updateTherapistStatus: async (therapistId: string, status: 'active' | 'pending' | 'rejected' | 'suspended'): Promise<User> => {
      return await api.request<User>(`/users/${therapistId}`, 'PUT', {
        status: status
      });
    },
    
    // Bekleyen terapistleri getir
    getPendingTherapists: async (): Promise<UsersListResponse> => {
      return await api.request<UsersListResponse>('/therapists/pending-approval');
    },
    
    // Aktif terapistleri getir
    getActiveTherapists: async (page = 1, limit = 10): Promise<UsersListResponse> => {
      return await api.request<UsersListResponse>(`/therapists?page=${page}&limit=${limit}`);
    },
    
    // Terapist Onaylama (YENİ)
    approveTherapist: async (therapistId: number): Promise<User> => {
      // PUT /api/therapists/approve/{id}
      // API.ts içindeki genel request fonksiyonu PUT metodunu destekliyor.
      // Backend sadece status kod döndürüyorsa ve body boşsa dönüş tipi SuccessResponse olabilir.
      // Şimdilik güncellenmiş User döndürdüğünü varsayalım.
      return await api.request<User>(`/therapists/approve/${therapistId}`, 'PUT');
    },
    
    // Terapist Reddetme (YENİ)
    rejectTherapist: async (therapistId: number): Promise<User> => {
      // PUT /api/therapists/reject/{id}
      // Backend sadece status kod döndürüyorsa ve body boşsa dönüş tipi SuccessResponse olabilir.
      // Şimdilik güncellenmiş User döndürdüğünü varsayalım (veya SuccessResponse).
      return await api.request<User>(`/therapists/reject/${therapistId}`, 'PUT');
    },
    
    // YENİ: Terapistin sadece seans ücretini getir
    getSessionFeeById: async (therapistId: number): Promise<{ sessionFee: number | null }> => {
      return await api.request<{ sessionFee: number | null }>(`/therapists/${therapistId}/session-fee`);
    },
  },
  
  // Toplantı API endpointleri
  meetings: {
    // Toplantı oluştur
    create: async (meetingData: CreateMeetingRequest): Promise<Meeting> => {
      return await api.request<Meeting>('/meetings', 'POST', meetingData);
    },
    
    // Toplantıları listele
    listAll: async (page = 1, limit = 10): Promise<MeetingsListResponse> => {
      return await api.request<MeetingsListResponse>(`/meetings?page=${page}&limit=${limit}`);
    },
    
    // Toplantı detayı getir
    getById: async (meetingId: string): Promise<Meeting> => {
      return await api.request<Meeting>(`/meetings/${meetingId}`);
    },
    
    // Toplantı bilgilerini güncelle
    updateById: async (meetingId: string, meetingData: UpdateMeetingRequest): Promise<Meeting> => {
      return await api.request<Meeting>(`/meetings/${meetingId}`, 'PUT', meetingData);
    },
    
    // Toplantı sil
    deleteById: async (meetingId: string): Promise<SuccessResponse> => {
      return await api.request<SuccessResponse>(`/meetings/${meetingId}`, 'DELETE');
    },
    
    // Katılımcı durumunu güncelle
    updateParticipantStatus: async (meetingId: string, status: ParticipantStatus): Promise<Meeting> => {
      return await api.request<Meeting>(`/meetings/${meetingId}/participant-status`, 'PUT', { status });
    }
  },
  
  // Bookings API endpointleri (Yeni eklendi)
  bookings: {
    // Yeni randevu oluştur
    create: async (bookingData: any): Promise<any> => { // TODO: BookingRequest tipi tanımla
      return await api.request<any>('/bookings', 'POST', bookingData);
    },
    // Kullanıcının randevularını listele
    listForUser: async (userId: number): Promise<any[]> => { // TODO: Booking[] tipi tanımla
      return await api.request<any[]>(`/bookings/user/${userId}`);
    },
    // Terapistin randevularını listele (YENİ)
    listForTherapist: async (therapistId: number): Promise<any[]> => { // TODO: Booking[] tipi tanımla
      return await api.request<any[]>(`/bookings/therapist/${therapistId}`);
    },
    // Diğer booking endpointleri eklenebilir (getById, update, delete)
  },
  
  // Ratings API endpointleri (YENİ)
  ratings: {
    // Kullanıcının puanlanmamış booking'lerini getir (güncellendi)
    getNotRatedBookings: async (userId: number): Promise<NotRatedBookingsResponse> => {
      // :userId path parametresi olduğu için template literal kullan
      return await api.request<NotRatedBookingsResponse>(`/ratings/not-rated-bookings/${userId}`); 
    },
    
    // Yeni bir puanlama/yorum gönder (parametre tipi güncellendi)
    submitRating: async (ratingData: SubmitRatingRequest): Promise<Rating> => {
      return await api.request<Rating>('/ratings', 'POST', ratingData);
    },
    
    // YENİ: Tüm terapistlerin rating istatistiklerini getir
    getAllRatings: async (): Promise<RatingsListResponse> => {
      return await api.request<RatingsListResponse>('/ratings');
    }
    // Diğer rating endpointleri eklenebilir (getForTherapist, getAverage vb.)
  }
};

export default api;