// API Response Tipleri

// Kullanıcı Tipleri
export type UserRole = 'customer' | 'therapist' | 'admin';
export type UserStatus = 'active' | 'pending' | 'suspended' | 'inactive';
export type Gender = 'erkek' | 'kadın' | 'diğer';

// Döküman tipleri
export type DocumentType = 'diploma' | 'certificate' | 'license' | 'identity' | 'other';

export interface Document {
  _id: string;
  userId: string;
  name: string;
  type: DocumentType;
  fileUrl: string;
  uploadDate: string;
  verified: boolean;
}

export interface BaseUser {
  id: number;
  name: string;
  email: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: Gender;
  address?: string;
  role: UserRole;
  status: UserStatus;
  profilePicture?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerUser extends BaseUser {
  role: 'customer';
}

export interface TherapistUser extends BaseUser {
  role: 'therapist';
  specialty?: string;
  licenseNumber?: string;
  educationBackground?: string;
  yearsOfExperience?: number;
  bio?: string;
  sessionFee?: number;
  documents?: Document[];
}

export interface AdminUser extends BaseUser {
  role: 'admin';
}

export type User = CustomerUser | TherapistUser | AdminUser;

// Kullanıcı Kayıt İstekleri
export interface RegisterCustomerRequest {
  name: string;
  email: string;
  password: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: Gender;
  address?: string;
}

export interface RegisterTherapistRequest extends RegisterCustomerRequest {
  specialty?: string;
  licenseNumber?: string;
  educationBackground?: string;
  yearsOfExperience?: number;
  bio?: string;
  sessionFee?: number;
}

export interface RegisterAdminRequest {
  name: string;
  email: string;
  password: string;
}

// Login İsteği
export interface LoginRequest {
  email: string;
  password: string;
}

// Profil Güncelleme İsteği
export interface UpdateProfileRequest {
  name?: string;
  phone?: string;
  address?: string;
  password?: string;
  profilePicture?: string | null;
  // Terapist için ek alanlar
  specialty?: string;
  bio?: string;
  educationBackground?: string;
  sessionFee?: number | null;
}

// Döküman Yükleme İsteği
export interface UploadDocumentRequest {
  name: string;
  type: DocumentType;
  file: string; // Base64 encoded file
}

// Döküman Yanıtı
export interface DocumentResponse {
  document: Document;
  message: string;
}

// Dökümanlar Yanıtı
export interface DocumentsListResponse {
  documents: Document[];
  total: number;
}

// Toplantı Tipleri
export type MeetingType = 'video' | 'audio' | 'in-person';
export type MeetingStatus = 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
export type ParticipantStatus = 'accepted' | 'declined' | 'pending';
export type RecurrencePattern = 'daily' | 'weekly' | 'monthly';

export interface Meeting {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  hostId: string;
  host?: Partial<User>;
  participants: {
    userId: string;
    status: ParticipantStatus;
  }[];
  meetingType: MeetingType;
  meetingLink?: string;
  notes?: string;
  status: MeetingStatus;
  isRecurring: boolean;
  recurrencePattern?: RecurrencePattern;
  createdAt: string;
  updatedAt: string;
}

// Toplantı Oluşturma İsteği
export interface CreateMeetingRequest {
  title: string;
  description?: string;
  startTime: string;
  endTime: string;
  meetingType: MeetingType;
  meetingLink?: string;
  notes?: string;
  isRecurring?: boolean;
  recurrencePattern?: RecurrencePattern;
  participantIds?: string[];
}

// Toplantı Güncelleme İsteği
export interface UpdateMeetingRequest {
  title?: string;
  description?: string;
  startTime?: string;
  endTime?: string;
  meetingType?: MeetingType;
  meetingLink?: string;
  notes?: string;
  status?: MeetingStatus;
  isRecurring?: boolean;
  recurrencePattern?: RecurrencePattern;
}

// API Yanıt Tipleri
export interface AuthResponse {
  token: string;
  user: User;
}

export interface UsersListResponse {
  users: User[];
  total: number;
  page: number;
  limit: number;
}

export interface MeetingsListResponse {
  meetings: Meeting[];
  total: number;
  page: number;
  limit: number;
}

export interface SuccessResponse {
  success: boolean;
  message: string;
}

// Müsaitlik Zamanı Tipi
export interface Availability {
  id: number; // Backend modeline göre number
  userId: number;
  dayOfWeek: string; // 'monday', 'tuesday', etc.
  isWeekday: boolean;
  startTime: string; // 'HH:mm:ss' formatında
  endTime: string; // 'HH:mm:ss' formatında
  isAvailable: boolean;
  createdAt: string; // Veya Date?
  updatedAt: string; // Veya Date?
}

// --- Rating Tipleri --- 

// GET /ratings/not-rated-bookings/:userId yanıtı için tek bir booking objesi
export interface NotRatedBooking {
  id: number; // bookingId -> id olarak düzeltildi
  sessionDate: string; // Veya bookingDate?
  startTime: string;
  endTime: string;
  status: string; // Muhtemelen 'completed'
  therapistId: number;
  userId: number;
  therapist: { // İç içe terapist bilgileri
    id: number;
    name: string;
    specialty?: string;
    profilePicture?: string;
  };
  // sessionId artık burada olmayabilir
}

// POST /ratings için istek gövdesi (bookingId bekliyor, bu doğru)
export interface SubmitRatingRequest {
  bookingId: number; 
  rating: number; // 1-5
  comment?: string;
  isAnonymous?: boolean;
}

// POST /ratings başarılı yanıtı (ve genel Rating modeli) (bookingId içeriyor)
export interface Rating {
  id: number;
  userId: number;
  therapistId: number;
  bookingId: number; // Bu alan backend'den geliyorsa kalmalı
  sessionId?: number; 
  rating: number;
  comment?: string;
  isAnonymous?: boolean;
  createdAt: string;
  updatedAt: string;
}

// GET /ratings/not-rated-bookings/:userId için API yanıtı (dizi)
export type NotRatedBookingsResponse = NotRatedBooking[];

// Eski tipleri kaldırabiliriz (opsiyonel)
// export interface NotRatedSession { ... }
// export type NotRatedSessionsResponse = NotRatedSession[];

// GET /api/ratings yanıtındaki her bir terapist istatistiği için tip
export interface TherapistRatingStat {
  therapistId: number;
  averageRating: number;
  totalRatings: number;
  therapist: {
    id: number;
    name: string;
    specialty?: string;
    profilePicture?: string;
  };
}

// GET /api/ratings için API yanıtı (dizi)
export type RatingsListResponse = TherapistRatingStat[];