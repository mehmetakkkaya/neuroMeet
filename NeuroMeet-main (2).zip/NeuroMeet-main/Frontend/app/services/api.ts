// Bu dosya relatif import ifadelerinin çalışması için kullanılıyor
// Örneğin: import api from '../../services/api'
export { default } from '../../src/services/api'; 